$(document).ready(function(){

	$.get('http://www.templateapi.com/themes/log?id='+1076263+'&oi='+66+'&ot=1&&url='+window.location, function(json){})    

});